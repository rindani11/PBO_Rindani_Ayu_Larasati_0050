/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.responsi_pbo;

/**
 *
 * @author rindaaaa
 */
public class Responsi_PBO {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
