/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SistemManajemen;

/**
 *
 * @author rindaaaa
 */
public class Produk {
     // Atribut dibuat private untuk menerapkan enkapsulasi
    private String namaProduk;
    private double harga;
    
     // Getter untuk mengambil nilai nama produk
    public String getNamaProduk() {
        return namaProduk;
    }
     // Setter untuk mengubah atau memberi nilai nama produk
    public void setNamaProduk(String namaProduk) {
        this.namaProduk = namaProduk;
    }

    public double getHarga() {
        return harga;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }
    // Method untuk menampilkan informasi produk
    public void tampilkanInfo() {
        System.out.println("Nama Produk : " + namaProduk);
        System.out.println("Harga       : " + harga);
    }
}
