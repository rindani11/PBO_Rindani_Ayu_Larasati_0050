/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SistemManajemen;

/**
 *
 * @author rindaaaa
 */
public class Main {
    public static void main(String[] args) {

        // 1. POLIMORFISME PRODUK // Membuat objek Elektronik dengan referensi class Produk
        Produk produk1 = new Eelektronik();
        
        // Memberikan nilai pada atribut melalui setter
        produk1.setNamaProduk("Laptop");
        produk1.setHarga(12000000);
        
        // Mengubah tipe referensi Produk menjadi Elektronik
        Eelektronik elektronik = (Eelektronik) produk1;
        elektronik.setGaransi(2); // Memberikan nilai garansi pada objek Elektronik

        produk1.tampilkanInfo();  // Method yang dijalankan adalah milik class Elektronik


        System.out.println();
        
        
        // 2. POLIMORFISME PEGAWAI
        Pegawai pegawai1 = new PegawaiTetap();

        pegawai1.setNamaPegawai("Rindani Ayu Larasati");
        pegawai1.setGaji(10000000);

        PegawaiTetap pegawaiTetap = (PegawaiTetap) pegawai1;
        pegawaiTetap.setTunjangan(1000000);

        pegawai1.tampilkanInfo();


        System.out.println();

        
        // 3. POLIMORFISME PRODUK MAKANAN
        Produk produk2 = new Makanan();

        produk2.setNamaProduk("Snack");
        produk2.setHarga(15000);

        Makanan makanan = (Makanan) produk2;
        makanan.setTanggalKadaluarsa("2023-12-30");

        produk2.tampilkanInfo();


        System.out.println();


        // 4. POLIMORFISME PEGAWAI KONTRAK
        Pegawai pegawai2 = new PegawaiKontrak();

        pegawai2.setNamaPegawai("Andi");
        pegawai2.setGaji(3000000);

        PegawaiKontrak pegawaiKontrak =
                (PegawaiKontrak) pegawai2;

        pegawaiKontrak.setLamaKontrak(12);

        pegawai2.tampilkanInfo();
    }
}
    
