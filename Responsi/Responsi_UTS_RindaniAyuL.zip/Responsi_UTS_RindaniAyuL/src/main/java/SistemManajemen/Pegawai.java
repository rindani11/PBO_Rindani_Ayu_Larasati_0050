/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SistemManajemen;

/**
 *
 * @author rindaaaa
 */
public class Pegawai {
    // Atribut dibuat private untuk menerapkan enkapsulasi
    private String namaPegawai;
    private double gaji;
    
    // Getter untuk mengambil nama pegawai
    public String getNamaPegawai(){
        return namaPegawai;
    }
    // Setter untuk mengubah atau memberi nama pegawai
    public void setNamaPegawai(String namaPegawai){
        this.namaPegawai = namaPegawai;
    }
    public double getGaji(){
        return gaji;
    }
    public void setGaji(double gaji){
        this.gaji = gaji;
    }
    // Method untuk menampilkan informasi pegawai
    public void tampilkanInfo() {
        System.out.println("Nama Pegawai : " + namaPegawai);
        System.out.println("Gaji         : " + gaji);
    }
    
}
