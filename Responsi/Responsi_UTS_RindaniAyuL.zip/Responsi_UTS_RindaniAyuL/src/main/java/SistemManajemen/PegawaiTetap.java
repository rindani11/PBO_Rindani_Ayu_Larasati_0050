/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SistemManajemen;

/**
 *
 * @author rindaaaa
 */
public class PegawaiTetap extends Pegawai { //// PegawaiTetap merupakan turunan dari class Pegawai
    private double tunjangan; // Atribut khusus untuk pegawai tetap
    
    public double getTunjangan(){
        return tunjangan;
    }
    public void setTunjangan(double tunjangan){
        this.tunjangan = tunjangan;
    }
    @Override
    public void tampilkanInfo(){
        System.out.println("Nama Pegawai: " + getNamaPegawai());
        System.out.println("Gaji: " + String.format("%.0f", getGaji()));
        System.out.println("Tunjangan: " + tunjangan);
    }
    
}
