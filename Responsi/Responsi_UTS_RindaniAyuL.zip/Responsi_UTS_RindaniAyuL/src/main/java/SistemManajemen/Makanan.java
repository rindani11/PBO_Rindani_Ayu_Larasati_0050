/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SistemManajemen;

/**
 *
 * @author rindaaaa
 */
public class Makanan extends Produk{ //turunan class Produk
    private String tanggalKadaluarsa; //atribut khusus
    
    public String getTanggalkadaluarsa(){
        return tanggalKadaluarsa;
    }
    public void setTanggalKadaluarsa(String tanggalKadaluarsa){
        this.tanggalKadaluarsa = tanggalKadaluarsa;
    }
    @Override
    public void tampilkanInfo(){
       System.out.println("Nama Produk : " + getNamaProduk());
       System.out.println("Harga       : " + String.format("%.0f", getHarga()));
       System.out.println("Tanggal Kadaluarsa: " + tanggalKadaluarsa); 
    }
}
