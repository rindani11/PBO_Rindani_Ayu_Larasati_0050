/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SistemManajemen;

/**
 *
 * @author rindaaaa
 */
public class Eelektronik extends Produk{ //turunan class Produk
    private int garansi;
    
    public int getGaransi(){ //Atribut khusus 
        return garansi;
    }
    public void setGaransi(int garansi){
        this.garansi = garansi;
    }
    @Override
    public void tampilkanInfo() {
       System.out.println("Nama Produk : " + getNamaProduk());
       System.out.println("Harga       : " + String.format("%.0f",getHarga()));
       System.out.println("Garansi     : " + garansi + " tahun"); 
        
    }
    
}
