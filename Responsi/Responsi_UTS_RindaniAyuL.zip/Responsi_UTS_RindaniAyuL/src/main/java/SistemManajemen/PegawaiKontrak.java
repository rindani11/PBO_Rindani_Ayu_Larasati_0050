/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SistemManajemen;

/**
 *
 * @author rindaaaa
 */
public class PegawaiKontrak extends Pegawai { // PegawaiKontrak merupakan turunan dari class Pegawai
    private int lamaKontrak; // Atribut khusus untuk pegawai kontrak
    
    public int getLamaKontrak(){
        return lamaKontrak;
    }
    public void setLamaKontrak(int lamaKontrak){
        this.lamaKontrak = lamaKontrak;
    }
    @Override
    public void tampilkanInfo(){
      System.out.println("Nama Pegawai: " + getNamaPegawai());
      System.out.println("Gaji: " + String.format("%.0f", getGaji()));
      System.out.println("Lama Kontrak: " + lamaKontrak + " bulan");  
    }  
}
