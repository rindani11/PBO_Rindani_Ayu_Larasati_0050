/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_5;

/**
 *
 * @author rindaaaa
 */
public class SepedaMotor extends Kendaraan {
    String jenisMesin;
    
    // Konstruktor
    public SepedaMotor(String nama, int kecepatan, String jenisMesin){
        super(nama, kecepatan); // Memanggil konstruktor kelas Kendaraan
        this.jenisMesin = jenisMesin;
    }
    // Override 
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Jenis Mesin: " + jenisMesin);
    }
    
}

