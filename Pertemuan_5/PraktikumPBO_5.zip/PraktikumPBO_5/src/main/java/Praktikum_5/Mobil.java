/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_5;

/**
 *
 * @author rindaaaa
 */
public class Mobil extends Kendaraan{
    int jumlahPintu;
    
    // KOnstruktor
    public Mobil(String nama, int kecepatan, int jumlahPintu) {
        super(nama, kecepatan); // Memanggil konstruktor class Kendaraan
    }
    // Menampilkan info Mobil
    public void tampilkanInfoMobil() {
      System.out.println("---Informasi Mobil---");
      tampilkanInfo();
    }
    // Overriding
    @Override
    public void tampilkanInfo(){
        super.tampilkanInfo();
        System.out.println("Jumlah Pintu  : " + jumlahPintu);
    }
}
