/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_5;

/**
 *
 * @author rindaaaa
 */
public class Kendaraan {
    String nama;
    int kecepatan;
    
    // Konstruktor
    public Kendaraan(String nama, int kecepatan) {
        this.nama = nama;
        this.kecepatan = kecepatan;
    }
    // Menampilkan informasi
    public void tampilkanInfo() {
        System.out.println("Nama Kendaraan: " + nama);
        System.out.println("Kecepatan     : " + kecepatan + "km/jam");
    }
    
}
