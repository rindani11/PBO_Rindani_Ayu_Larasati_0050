/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_5;

/**
 *
 * @author rindaaaa
 */
public class Main {
    public static void main(String[] args) {
        Mobil mobil = new Mobil("Toyota", 180, 4);
        mobil.tampilkanInfo();
        
        System.out.println();
        
        SepedaMotor motor = new SepedaMotor("Yahama", 120, "2-tak");
        motor.tampilkanInfo();
    }
    
}
