/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_5;

/**
 *
 * @author rindaaaa
 */
public class Anjing extends Hewan {

    public Anjing(String nama) {
        super(nama, "Mamalia");
    }
    @Override
    public void bersuara() {
        System.out.println("Suara : Guk Guk!");
    }
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        bersuara();
    }
    
}
