/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_5;

/**
 *
 * @author rindaaaa
 */
public class Kendaraan {
    String nama;

    public Kendaraan(String nama) {
        this.nama = nama;
    }

    public void tampilkanInfo() {
        System.out.println("Nama Kendaraan: " + nama);
    }
}
