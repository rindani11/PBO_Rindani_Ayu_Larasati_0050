/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_5;

/**
 *
 * @author rindaaaa
 */
public class Main {
    public static void main(String[] args){
        System.out.println("---Objek Kucing---");
        Kucing kucing1 = new Kucing("Mimi");
        kucing1.tampilkanInfo();
        
        System.out.println();
        
        System.out.println("---Objek Anjing---");
        Anjing anjing1 = new Anjing("Pupy");
        anjing1.tampilkanInfo();
        
        System.out.println();
        
        System.out.println("Uji Coba Hierarki");
        Mobil mobil1 = new Mobil("Toyota Avanza", 4, 4);
        mobil1.tampilkanInfo();
        
        System.out.println();
        
        SepedaMotor motor1 = new SepedaMotor("Honda Vario", 2, "Authomatic 4-tak");
        motor1.tampilkanInfo();   
    }
    
}
