/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_5;

/**
 *
 * @author rindaaaa
 */
public class Hewan {
    String nama;
    String jenisHewan;
    
    // Konstruktor
    public Hewan(String nama, String Hewan){
        this.nama = nama;
        this.jenisHewan = jenisHewan;
        
    }
    public void tampilkanInfo() {
        System.out.println("Nama Hewan   : " + nama);
        System.out.println("Jenis Hewan  : " + jenisHewan);
    }
    public void bersuara(){
        System.out.println("Hewan ini membuat suara");
    }
}
