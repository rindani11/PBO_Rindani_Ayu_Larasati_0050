/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_3;

/**
 *
 * @author rindaaaa
 */
public class Main {
    public static void main(String[]args){
        Hewan kucing = new Hewan ("Moy", 10);
        kucing.suara();
        kucing.info();
        
         Hewan anjing = new Hewan ("atan", 1);
         anjing.berlari();
         anjing.info();
    }
    
}
