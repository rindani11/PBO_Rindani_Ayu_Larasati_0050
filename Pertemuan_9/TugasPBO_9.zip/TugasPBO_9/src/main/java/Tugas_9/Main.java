/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_9;

/**
 *
 * @author rindaaaa
 */
public class Main {
    public static void main(String[] args){
        Hewan hewan1 = new Kucing();
        Hewan hewan2 = new Anjing();
        
        hewan1.suara();
        hewan2.suara();
 
    }
    
}
