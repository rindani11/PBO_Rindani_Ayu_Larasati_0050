/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugaspbo_9;

/**
 *
 * @author rindaaaa
 */
public class TugasPBO_9 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
