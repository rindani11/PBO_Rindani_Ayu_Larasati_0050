/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_9;

/**
 *
 * @author rindaaaa
 */
public abstract class Kendaraan {
    public abstract void berjalan(); //metode abstract
    
    public void info(){ //metode dengan implementasi
        System.out.println("Ini adalah kendaraan.");
    }
    
}
