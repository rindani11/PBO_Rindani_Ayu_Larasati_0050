/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_9;

/**
 *
 * @author rindaaaa
 */
public class Sepeda extends Kendaraan {
    @Override
    public void berjalan(){
        System.out.println("Sepeda sedang berjalan dengan pelan.");
    }
    
}
