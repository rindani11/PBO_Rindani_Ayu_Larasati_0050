/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_10;

/**
 *
 * @author rindaaaa
 */
public class Penjumlahan implements OperasiHitung {
    @Override
    public int hitung(int a, int b){
        return a + b;
    } 
}
