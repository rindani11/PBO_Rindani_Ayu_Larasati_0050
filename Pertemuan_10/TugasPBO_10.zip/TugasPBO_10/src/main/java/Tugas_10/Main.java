/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_10;

/**
 *
 * @author rindaaaa
 */
public class Main {
    public static void main(String[] args){
        //Objek Elektronik
        Pembayaran Laptop = new Elektronik();
        System.out.println("Pajak Elektronik: " + Laptop.hitungPajak(5000000));
        
        //Objek Makanan
        Pembayaran Roti = new Makanan();
        System.out.println("Pajak Makanan: " + Roti.hitungPajak(10000));   
    }   
}
