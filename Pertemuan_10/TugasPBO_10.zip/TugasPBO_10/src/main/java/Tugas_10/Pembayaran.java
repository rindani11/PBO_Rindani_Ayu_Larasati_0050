/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_10;

/**
 *
 * @author rindaaaa
 */
public interface Pembayaran {
    double hitungPajak(double harga);   
}
