/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_4;

/**
 *
 * @author rindaaaa
 */
public class Kendaraan {
    //Atribut dengan akses modifier berbeda
    private String nama;           // Hanya bisa diakses dalam kelas ini
    protected int kecepatanmx;     // Bisa diakses di package yg sama & subclass
    public String jenisMesin;      // Bisa diakses dari mana saja
    
    // Constructor
    public Kendaraan(String nama, int kecepatanmx, String jenisMesin) {
        this.nama = nama;
        this.kecepatanmx = kecepatanmx;
        this.jenisMesin = jenisMesin;
    }
    // Getter dan Setter untuk variabel private nama
    public String getNama(){
        return nama;
    }    
    public void setNama(String nama){
        this.nama = nama;
    }
    // Method public untuk menampilkan informasi kendaraan
    public void tampilkaninfokendaraan(){
        System.out.println("Nama Kendaraan: " + nama);
        System.out.println("Kecepatan Maksimum: " + kecepatanmx + " km/h");
        System.out.println("Jenis Mesin: " + jenisMesin);
        
    }
    
    
    
}
