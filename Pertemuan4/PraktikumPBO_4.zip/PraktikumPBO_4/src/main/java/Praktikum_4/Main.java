/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_4;

/**
 *
 * @author rindaaaa
 */
public class Main {
    public static void main(String[] args){
        Kendaraan kendaraan1 = new Kendaraan("Sepeda Motor", 120, "Bensin");
        
        //Menampilkan data awal
        System.out.println("Informasi Kendaraan: " );
        System.out.println("Nama: " + kendaraan1.getNama());
        System.out.println("Kecepatan Maks: " + kendaraan1.kecepatanmx + " km/h"); 
        System.out.println("Jenis Mesin: " + kendaraan1.jenisMesin );
        
        System.out.println(); //Baris baru/ pemisah
        
        //Membuat objek Mobil(menggunakan kelas Mobil
        Mobil mobil1 = new Mobil("Avanza", 180, "Bensin", 4);
        
        //Menampilkan informasi Mobil
        System.out.println("Informasi Mobil: ");
        mobil1.tampilkaninfoMobil();
    }
    
}
