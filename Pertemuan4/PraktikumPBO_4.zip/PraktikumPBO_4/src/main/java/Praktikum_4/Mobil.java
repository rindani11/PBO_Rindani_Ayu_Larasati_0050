/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_4;

/**
 *
 * @author rindaaaa
 */
public class Mobil extends Kendaraan {
    private int jumlahPintu; //Atribut tambahan khusus untuk Mobil
    
    //Constructor
    public Mobil(String nama, int kecepatanmx, String jenisMesin, int jumlahPintu)  {
        super(nama, kecepatanmx, jenisMesin);
        this.jumlahPintu = jumlahPintu;
    }
    
    // Method untuk menampilkan informasi Mobil
    public void tampilkaninfoMobil(){
        //Dapat mengakses kecepatanmx karena protected
        System.out.println("Kecepatan Maksimum Mobil: " + kecepatanmx + " km/h");
        System.out.println("Jumlah Pintu: " + jumlahPintu);
    }
    
}
