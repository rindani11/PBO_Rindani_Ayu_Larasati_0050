/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_4;

/**
 *
 * @author rindaaaa
 */
public class Main {
    public static void main(String[] args) {
        // Membuat objek Pekerja
        Pekerja pekerja1 = new Pekerja("Budi Santoso", 30, "Software Engineer", 12000000);

        // Menampilkan informasi awal pekerja menggunakan toString()
        System.out.println("Informasi Pekerja:");
        System.out.println(pekerja1.toString());

        System.out.println(); 

        // Mengubah nama pekerja menggunakan metode setter
        pekerja1.setNama("Budi Pratama");

        // Menampilkan ulang informasi pekerja setelah diubah
        System.out.println("Informasi Pekerja Setelah Nama Diubah:");
        System.out.println(pekerja1.toString());

        System.out.println(); 

        // Pengujian Akses Langsung Atribut:
        System.out.println("Percobaan Akses Langsung:");
        System.out.println("Pekerjaan: " + pekerja1.pekerjaan); 
        System.out.println("Usia: " + pekerja1.usia);           

        // Jika baris di bawah ini dihilangkan tanda komentarnya (//), program akan ERROR:
         //System.out.println("Nama: " + pekerja1.nama); // ERROR: nama bersifat private di Manusia
        // System.out.println("Gaji: " + pekerja1.gaji); // ERROR: gaji bersifat private di Pekerja
    }
    
}
