/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum_6;

/**
 *
 * @author rindaaaa
 */
public class Kucing extends Hewan {
    @Override
    public void bersuara(){
        System.out.println("Meow");
    }
    
}
