/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_6;

/**
 *
 * @author rindaaaa
 */
public class Main {
    public static void main(String[] args) {
        // Membuat objek KeranjangBelanja
        KeranjangBelanja keranjang = new KeranjangBelanja();

        // Membuat beberapa objek produk
        Produk buku1 = new Buku("Buku Pemrograman Java", 100000);
        Produk laptop = new Elektronik("Laptop Gaming", 10000000);
        Produk kaos = new Pakaian("Kaos Polos", 50000);

        // Menambahkan produk ke keranjang
        keranjang.tambahProduk(buku1);
        keranjang.tambahProduk(laptop);
        keranjang.tambahProduk(kaos);

        // Menampilkan rincian belanjaan dan total akhir
        keranjang.tampilkanRincian();
    }
}
