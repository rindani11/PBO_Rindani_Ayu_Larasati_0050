/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_6;

/**
 *
 * @author rindaaaa
 */
import java.util.ArrayList;
import java.util.List;

public class KeranjangBelanja {
    private List<Produk> listProduk;

    public KeranjangBelanja() {
        listProduk = new ArrayList<>();
    }

    public void tambahProduk(Produk produk) {
        listProduk.add(produk);
        System.out.println(produk.getNama() + " berhasil ditambahkan ke keranjang.");
    }

    public double hitungTotalHarga() {
        double total = 0;
        for (Produk p : listProduk) {
            total += p.getHargaSetelahDiskon();
        }
        return total;
    }

    public void tampilkanRincian() {
        System.out.println("\n=== RINCIAN KERANJANG BELANJA ===");
        for (Produk p : listProduk) {
            System.out.println("- " + p.getNama() + 
                               " | Harga Awal: Rp " + p.getHarga() + 
                               " | Diskon: Rp " + p.hitungDiskon() + 
                               " | Harga Akhir: Rp " + p.getHargaSetelahDiskon());
        }
        System.out.println("------------------------------------");
        System.out.println("TOTAL HARGA SETELAH DISKON: Rp " + hitungTotalHarga());
    }
    
}
